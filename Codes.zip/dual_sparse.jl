using JuMP
using Distributions, Gurobi
using MathProgBase
using JLD, Mosek

############################
include("functions.jl")
include("function_sparse_cuttingplane.jl")
include("function_sparse_MIObigM.jl")
############################
# n = No. of samples
# d = No. of features
# k = Sparsity level
# tol = Tolerance level; 0.2 worked well in the expts.
# filenum = Instance number.
# time_limit = Time limit for Gurobi Solver (in seconds).
# lambda = lambda for regularization. Choose via cross validation. 0.01 worked well in the expts.
n = parse(Int,ARGS[1])
d = parse(Int,ARGS[2])
k = parse(Int,ARGS[3])
tol = parse(Float64, ARGS[4])
filenum = parse(Int,ARGS[5]) # controls input data -> between 1 and 10.
time_limit = parse(Int, ARGS[6]) 
lambda = parse(Float64, ARGS[7]);
rho = parse(Float64, ARGS[8]) # Rho \in {0.0, 0.1, 0.5}.
snr = parse(Int, ARGS[9]); # SNR = \{ 3, 9, 400}

X=[];
y=[];
S_true=[];
if(isfile("/TestInstances/Rho$rho\_SNR$snr/Data$filenum\_d$d\_k$k.jld") )
	workspace_JLD_path = "/TestInstances/Rho$rho\_SNR$snr/Data$filenum\_d$d\_k$k.jld"
		
	ws = load(workspace_JLD_path)
	S_true = ws["S_true"]
	X = ws["X_train"]
	y = ws["y_train"]
end 

# (1/2)*error + (1/2)*lambda*Regularizer.

rand_idxs = zeros(Int64,n,2)
Pairs = Array(Vector{Int64}, n);
r = 1
for i in 1:n
  # Select r points randomly from n-1 available.
  ind2 = sample(setdiff(collect(1:n),i),r,replace=false)
  rand_idxs[i,1] = i
  rand_idxs[i,2] = copy(ind2[1]);
  Pairs[i] = copy(vec(rand_idxs[i,2:end]));
end


# Convergence parameters 
max_outer_iter = 100;
tol_outer_convergence = 1e-3;
max_inner_iter = 100;
tol_inner_convergence = 1e-2;
infeasibility_tol = tol;


t1 = time()
best_heuristic_set = relaxation_heuristic(X[1:num_small,:],y[1:num_small],k,0.01, rand_idxs_small, Reverse_pairs_small, nonempty_reverse_small, 1000, lambda)
t2 = time()
	
H1_time = t2 - t1;

S_0 = sort(best_heuristic_set);

# Set up outer binary optimization problem.
getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
m_outer = Model(solver=GurobiSolver(Threads=getthreads(), TimeLimit=time_limit, MIPGap = 1e-2)) #MIPGap= 5e-4
@variable(m_outer, z[1:d], Bin)
@variable(m_outer, t_var >= 0)
@constraint(m_outer, sum{z[i], i in 1:d} <= k)
@objective(m_outer, Min, t_var )

z_iter = zeros(d);
for i in 1:d
	if(in(i, S_0) == 1)
		setvalue(z[i], 1.0);
		z_iter[i] = 1.0;
	else
		setvalue(z[i], 0.0);
		z_iter[i] = 0;
	end
end
~, ~, ~, ~, ~,~, ~, ~,t_var_ws = L2_cutting_plane_LARGE_L2reg(X[:,S_0],y,1000,tol,100*ones(size(S_0)),0,1, lambda)
setvalue(t_var, t_var_ws);

#############
if(0 < t_var_ws) 
	g_val, grad_g = SolvePrimalCuttingPlanes_PrimalConstraintGen(X, y, k, z_iter, lambda, Pairs, max_inner_iter, infeasibility_tol);
	@constraint(m_outer, g_val + sum{grad_g[i]*(z[i] - z_iter[i]), i = 1:d} <= t_var)
end

println("-----------------------------------------------")

#### Lazy callbacks ####


function lazycuts(cb)
	z_val = getvalue(z)
	t_val = getvalue(t_var)
	# Allow for some impreciseness in the solution
	TOL = 1e-3;

		
	g_val, grad_g = SolvePrimalCuttingPlanes_PrimalConstraintGen(X, y, k, z_val, lambda, Pairs, max_inner_iter, infeasibility_tol);
	@show g_val - t_val 
			
	if(g_val > t_val + TOL )
		# Cut off this solution.
		@lazyconstraint(cb, g_val + sum{grad_g[i]*(z[i] - z_val[i]), i = 1:d} <= t_var)
				
		println("Cut added")
	end
		
end  # End of callback function


addlazycallback(m_outer, lazycuts)

# Timing.
t_start = time();
status = solve(m_outer);
t_end = time();
solve_time = t_end - t_start;

z_val = getvalue(z)
t_val = getvalue(t_var);

S_opt = sort(find(z_val .>= 0.9));
@show sort(S_0)
@show sort(S_opt)
@show sort(S_true)
@show length(intersect(S_opt,S_true))/k;

## Store the results.