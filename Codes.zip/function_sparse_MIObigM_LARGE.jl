using JuMP
using Distributions, Gurobi
using MathProgBase

###################


function L2_sparse_cutting_plane_MIO_LARGE(X,y,k,max_cuts,tol,bigM,time_limit,mip_gap, z_0, theta_0, Xi_0)

  n = length(y)
  p = size(X,2)
  z_opt_path = Array(Vector{Int64},0);
  
  # Define the reduced master problem.
  getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
  m_outer = Model(solver=GurobiSolver(TimeLimit = time_limit, MIPGap= mip_gap, Threads=getthreads()))#(OutputFlag = 0))# Crossover=0
  @variable(m_outer,z[1:p],Bin)
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  
  @constraint(m_outer,UB_constr[i=1:p,j=1:n], Xi[j,i] <= bigM*z[i]);
  @constraint(m_outer,LB_constr[i=1:p,j=1:n], Xi[j,i] >= -bigM*z[i]);
  

  @constraint(m_outer, Cardinality_constr, sum{z[i], i in 1:p} <= k)
  # Solve the reduced problem.
  println("Adding the constraints")
  idxs = zeros(Int64,n,2);
  for i in 1:n
	ind2 = sample(setdiff(collect(1:n),i), 1, replace=false)[1];
	@constraint(m_outer, theta[i] + sum{(X[ind2,j] - X[i,j])*Xi[i,j], j =1:p} <= theta[ind2]);
	idxs[i,1] = copy(i);
	idxs[i,2] = copy(ind2);
	
  end
  
  @objective(m_outer, Min, sum{(y[i] - theta[i])*(y[i] - theta[i]), i=1:n})
  if(length(z_0) > 0)
	  setvalue(z,z_0)
	  setvalue(theta, theta_0)
	  setvalue(Xi, Xi_0)
  end
  println("Solving the model")
  status = solve(m_outer,suppress_warnings=true);
  
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);
  z_opt = getvalue(z)
  push!(z_opt_path, sort(find(z_opt .> 0.5)))
  @show find(z_opt .== 1)
  @show getobjectivevalue(m_outer)

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  new_idxs = zeros(Int64,n,2)

  # Adding cuts sequentially.
  while(cuts_added <= max_cuts-1 && opt_reached == 0)
    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.
	
	violation_pairs=[];
	
	for i in 1:n

		if (i%10000 == 0)
		  @show i
		end
		# To do: Do the multiplications manually.
		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]' ;
		separation_positive = max(separation,0);

		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = indmax(separation);
			push!(violation_pairs,[copy(i), copy(max_index[i])])
		else
			max_index[i] = 0;
		end

    end

    if(sum(max_index) == 0)
      opt_reached = 1;
	  print("Cutting plane converges \n")
	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
	  numcon = length(find(max_index .> 0))
	  new_idxs = zeros(Int64,numcon,2)
	  numcon_count = 1
      for i in 1:length(violation_pairs)
		i_star = violation_pairs[i][1];
        j_star = violation_pairs[i][2];
        if(j_star > 0 && i_star > 0 )
          @constraint(m_outer, theta[i_star] + sum{(X[j_star,ind] - X[i_star,ind])*Xi[i_star,ind], ind =1:p} <= theta[j_star] )
		  new_idxs[numcon_count,1] = copy(i_star) 
		  new_idxs[numcon_count,2] = copy(j_star)
		  numcon_count += 1
        end
      end
  
	  # Given current support, polish the feasible warm starts.
	  # Solve using Mosek with the current constraints.
	  # Use L2_cutting_plane_NEW
	  S_current = find(z_opt .>= 0.5)
	  @show S_current
	  # Construct new_idxs
	  # Solve with max_cuts = 0 -> only the current problem with the added constraints so far.
	  idxs = vcat(idxs,new_idxs)
	  
	  theta_opt, Xi_opt_1,~, ~, ~,~,~,~ =  L2_cutting_plane_NEW(X[:,S_current],y,0,0.1,10,idxs,bigM,0,1,1);
	  Xi_opt = zeros(n,d)
	  count_ind = 1
	  for i in 1:length(S_current)
		Xi_opt[:,S_current[i]] = Xi_opt_1[:,i]
	  end
	  
	  
	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  setvalue(z,z_opt);
	  
	  # Re-solve the problem.
	  @objective(m_outer, Min, sum{(y[i]-theta[i])*(y[i]-theta[i]), i=1:n} )
	  status = solve(m_outer,suppress_warnings=true);
	  push!(z_opt_path, sort(find(z_opt .> 0.5)))
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);
	  z_opt = getvalue(z)
	  @show find(z_opt.== 1)
	end
	# Loop counter.
	cuts_added = cuts_added+1;
  end # end while loop.
  
  @show cuts_added
  return theta_opt, Xi_opt, z_opt, getobjectivevalue(m_outer), cuts_added, z_opt_path
end

######################