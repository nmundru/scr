using JuMP
using JuMPeR
using Distributions, Gurobi
using MathProgBase
using HDF5, JLD, Mosek
using Distances, Stats

include("functions.jl")
############################
n = parse(Int,ARGS[3])
d = parse(Int,ARGS[4])
C = parse(Int, ARGS[5])


# Generate X, y.

y = zeros(n);
X = randn(n,d);
# Pre-processing. #
SNR = 3.0;
mu = zeros(n);
for i in 1:n
  mu[i] = norm(X[i,:],2)^2;
end
Var_mu = var(mu);
sigma_sq = Var_mu/SNR;
for i in 1:n
  noise = sqrt(sigma_sq)*randn(1);
  noise = noise[1];
  y[i] = mu[i] + noise;
end
# Post processing. #
# Zero mean and unit norm.
y_mean = sum(y)/n;
y = y - y_mean;
y = y/norm(y,2);
x_mean = zeros(d)
for i in 1:d
  x_mean[i] = sum([X[j,i] for j in 1:n])/n;
end
X = X - ones(n,1)*x_mean';
for i in 1:d
  X[:,i] = X[:,i]/norm(X[:,i],2);
end

############################

r = parse(Int, ARGS[1])
tol = parse(Float64, ARGS[2])

time_opt = 0
max_cuts = 100;
history = 50
bigM_array = 100*ones(d,1)
tic()
rand_idxs = zeros(Int64,n,r+1)
temp_array = 0;
for i in 1:n 

	rand_idxs[i,1] = i;
	rand_idxs[i,2:r+1] = sample(setdiff(collect(1:n),i),r,replace=false)
	
end
toc()
# First attempt.
tic()
~, ~, obj_val, opt_reached, cuts_array,Pinf_array,MaxV_array = L2_cutting_plane_NEW(X,y,max_cuts,tol,history,rand_idxs,bigM_array,0,0,1)

toc()

# Timing the functions.


t1 = time()
~, ~, obj_val, opt_reached, cuts_array,Pinf_array,MaxV_array = L2_cutting_plane_NEW(X,y,max_cuts,tol,history,rand_idxs,bigM_array,0,0,1)
t2 = time()
time_opt = (t2 - t1)

