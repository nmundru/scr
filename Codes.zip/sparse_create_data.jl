using JuMP
using Distributions, Gurobi
using MathProgBase
using JLD

############################
n = parse(Int,ARGS[1])
d = parse(Int,ARGS[2])
k = parse(Int,ARGS[3])
filenum = parse(Int,ARGS[4]) # controls input data.
rho = parse(Float64, ARGS[5]);
snr = parse(Int, ARGS[6]);# 3,9,400.

n_hat = Int(round(n)) # Adjust for test data.

S_true = sample(collect(1:d),k,replace=false)
@show S_true
y = zeros(n_hat);
X = randn(n_hat,d);
Sigma = eye(d,d);
for i in 1:d 
	for j in 1:d 
		Sigma[i,j] = rho^(abs(i-j));
	end
end

X = (rand(MvNormal(Sigma), n_hat))'

# Pre-processing. #
SNR = snr;
mu = zeros(n_hat);
for i in 1:n_hat
  mu[i] = sum([X[i,index]^2 for index in S_true]);
end
Var_mu = var(mu);
sigma_sq = Var_mu/SNR;
for i in 1:n_hat
  noise = sqrt(sigma_sq)*randn(1);
  noise = noise[1];
  y[i] = mu[i] + noise;
end


############################
num_train = n;
train_indices = sample(collect(1:n_hat),num_train,replace=false)

X_train = X[train_indices, :]
y_train = y[train_indices];

# Post processing. #
# Zero mean and unit norm.
y_train_mean = mean(y_train);
y_train = y_train - y_train_mean;
y_train = y_train/norm(y_train,2);


x_train_mean = zeros(d);
for i in 1:d
  x_train_mean[i] = sum([X_train[j,i] for j in 1:num_train])/num_train;
end
X_train = X_train - ones(num_train,1)*x_train_mean';

for i in 1:d
  X_train[:,i] = X_train[:,i]/norm(X_train[:,i],2);
end

save("InputData$filenum\_d$d\_k$k\_Rho$rho\_SNR$snr.jld", "n",n,"d",d,"k",k, "S_true",S_true,"X_train",X_train,"y_train",y_train);
