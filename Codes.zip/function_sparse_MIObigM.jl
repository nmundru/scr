using JuMP
using Distributions, Gurobi
using MathProgBase

###################

function L2_sparse_heuristic_small_exact(X,y,k,idxs,tau_0,gamma,tau_tol,theta_opt,Xi_opt,S_opt,Psi_1,Psi_2,tol_convergence)
	# Form matrices A, B_1,\ldots,B_n, 
	#
    n = length(y)
    d = size(X,2)
	numcon = size(idxs,1)
	A = zeros(numcon,n)
	B = zeros(numcon,d,n)
	for i in 1:numcon 
		A[i,idxs[i,1]] = 1
		A[i,idxs[i,2]] = -1
	end
	
	for i in 1:numcon
		ind1 = idxs[i,1]
		ind2 = idxs[i,2]
		B[i,:,ind1] = X[ind2,:] - X[ind1,:]
	
	end
	
	M = zeros(numcon, n+n*d)
	M[:,1:n] = A
	for i in 1:n  
		M[:,n+(i-1)*d+1:n+i*d] = B[:,:,i]
	end
	Lip = (maximum(svdvals(M)))^2
	@show Lip
	
	# Vary \tau 
	tau = tau_0
	# Iterative thresholding
	theta_new = zeros(n)
	Xi_new = zeros(n,d)
	S_new = zeros(Int64,k)
	
	while(tau > tau_tol)
		delta = 2*tol_convergence
		f_new = 100
		println("Local convergence for a given tau")
		@show tau
		while(delta > tol_convergence && f_new > 1e-4 )
		  # X,y,k,theta_opt, Xi_opt,idxs,Psi_1,Lip,eta,grad_theta,tau
			 S_new,theta_new,Xi_new,f_new,f_old = iterative_thresholding_given_L(X,y,k,theta_opt,Xi_opt,A,B,Lip,tau,idxs,Psi_1,Psi_2)
			 u = zeros(d)
			 for i in 1:d 
				u[i] = norm(Xi_new[:,i])
			 end
			 @show vecnorm(Xi_new-Xi_opt)
			 @show norm(theta_new-theta_opt)
			 @show find(u .> 0)
			 @show S_new
			 @show f_old 
			 @show f_new
			 delta = f_old - f_new
			 @show delta
			 S_opt = copy(S_new)
			 theta_opt = copy(theta_new)
			 Xi_opt = copy(Xi_new)
			 f_old = copy(f_new)
		  
		end # Inner convergence
		tau = copy(gamma*tau)
    end # Outer loop varying tau
  
  # return final support
  return S_new, theta_new, Xi_new
end


####

function iterative_thresholding_given_L(X,y,k,theta_opt, Xi_opt,A,B,Lip,tau,idxs,Psi_1,Psi_2)
  n = size(X,1)
  d = size(X,2)
  L_bar = copy(Lip)/tau
  lambda_dim = size(A,1)
  lambda = zeros(lambda_dim)
  lambda_new = zeros(lambda_dim)
  lambda_check = zeros(lambda_dim)
  lambda_check_new = zeros(lambda_dim)

  Xi_new = zeros(n,d)
  theta_new = zeros(n)
  S_new = zeros(Int64,k)
  S_new_check = zeros(Int64,k)
  zero_tol = 0
  lambda = A*theta_opt
  for i in 1:n 
	lambda += B[:,:,i]*Xi_opt[i,:]'
  end
  
  for i in 1:lambda_dim 
	lambda[i] = maximum([lambda[i]- zero_tol,0])
  end
  lambda = (1/tau)*lambda
  
  f_val_old = 0.5*norm(y-theta_opt)^2 + (0.5*tau)*norm(lambda,2)^2
  @show (0.5*tau)*norm(lambda,2)^2
  #@show f_val_old
  grad_theta = A'*lambda
  L_bar = copy(Lip)

  # Compute theta(L_bar), Xi(L_bar).
  u = zeros(d)
  Xi_new = zeros(n,d)
  for i in 1:n
	    grad_Xi = B[:,:,i]'*lambda
		
        Xi_new[i,:] = Xi_opt[i,:] - (1/L_bar)*(grad_Xi')
		#@show (1/L_bar)*(grad_Xi)
        for j in 1:d
           u[j] += Xi_new[i,j]^2
        end

  end
  @show sort(u,rev=true)[1:6]
  @show sortperm(u,rev=true)[1:6]
  # Sort u.
  S_new = sortperm(u,rev=true)
  S_new = S_new[1:k]
  #@show S_new

  # Form Xi_new, theta_new.
  theta_new = (1/(1+L_bar))*(y + L_bar*theta_opt - grad_theta)
	
  for i in 1:n
    for j in 1:d
        if(in(j,S_new) == 0)
           Xi_new[i,j] = 0
        end
    end
  end
	  
  lambda_new = A*theta_new
  for i in 1:n 
	lambda_new += B[:,:,i]*Xi_new[i,:]'
  end
  for i in 1:lambda_dim 
	lambda_new[i] = maximum([lambda_new[i]-zero_tol,0])
  end
  lambda_new = (1/tau)*lambda_new
    
  @show norm(lambda_new)
  @show maximum(lambda_new)
  f_val = 0.5*norm(y-theta_new)^2 + (0.5*tau)*norm(lambda_new,2)^2
  @show vecnorm(Xi_new)
  @show maximum(Xi_new)
  @show norm(y-theta_new)
  #@show f_val_old - f_val
  
  ## Now checking my code.
  for i in 1:lambda_dim
      i1 = idxs[i,1]
      i2 = idxs[i,2]
	  if(i1 >0 && i2 > 0)
		lambda_check[i] = maximum([(theta_opt[i1] + dot(vec(X[i2,:] - X[i1,:]),vec(Xi_opt[i1,:])) - theta_opt[i2]) ,0])
		  
	  end
  end
  lambda_check = lambda_check/tau
  
  #@show norm(lambda - lambda_check)

  f_val_old_check = 0.5*norm(y-theta_opt)^2 + (0.5)*tau*norm(lambda_check,2)^2
  f_val_check = 0
  grad_theta = zeros(n)
  for i in 1:n
	#@show Psi_1[i]
	#@show Psi_2[i]
    grad_theta[i] =  sum([lambda_check[j] for j in Psi_1[i]]) - sum([lambda_check[j] for j in Psi_2[i]])
  end
  

  # Compute theta(L_bar), Xi(L_bar).
  u = zeros(d)
  Xi_new_check = zeros(n,d)
  for i in 1:n
	    grad_Xi = zeros(1,d)
		if(length(Psi_1[i])>0)
			grad_Xi = sum([(X[idxs[ind,2],:] - X[i,:])*lambda_check[ind] for ind in Psi_1[i]])
		end
        Xi_new_check[i,:] = Xi_opt[i,:] - (1/L_bar)*(grad_Xi)
		#@show (1/L_bar)*(grad_Xi)
        for j in 1:d
           u[j] += Xi_new_check[i,j]^2
        end

  end
  #@show u
  # Sort u.
  S_new_check = sortperm(u,rev=true)
  S_new_check = S_new_check[1:k]
  #@show S_new_check
 
   # Form Xi_new, theta_new.
   theta_new_check = (1/(1+L_bar))*(y + L_bar*theta_opt - grad_theta)
		
    for i in 1:n
      for j in 1:d
        if(in(j,S_new_check) == 0)
          Xi_new_check[i,j] = 0
        end
      end
	  grad_Xi = zeros(d)'
	  if(length(Psi_1[i]) > 0)
		grad_Xi = sum([(X[idxs[ind,2],:] - X[i,:])*lambda_check[ind] for ind in Psi_1[i]])
	  end
    end
    # Evaluate f.

    for i in 1:lambda_dim
      i1 = idxs[i,1]
      i2 = idxs[i,2]
	  if(i1 >0 && i2 > 0)
		  
		lambda_check_new[i] = maximum([(theta_new[i1] + dot(vec(X[i2,:] - X[i1,:]),vec(Xi_new[i1,:])) - theta_new[i2]) ,0])
		  		  
	  end

    end
	lambda_check_new = lambda_check_new/tau
	#@show norm(lambda_new - lambda_check_new)
    f_val_check = 0.5*norm(y-theta_new)^2 + (0.5*tau)*norm(lambda_check_new,2)^2
	@show f_val_old, f_val
	@show f_val_old_check, f_val_check
  
    return S_new, theta_new, Xi_new, f_val, f_val_old
end
################## ACTUAL CODE ###################

function L2_sparse_heuristic(X,y,theta_opt,Xi_opt,S_opt,idxs,is_leq,Psi_1,Psi_2,Lip_0,eta,tol_convergence,tau_0, gamma, tau_tol, lambda_reg)

  # Start with tau_0
  # For each tau, perform IHT with backtracking till local optimum is reached.
  # Start with a k-sparse Xi_opt and theta_opt.
  n = length(y)
  d = size(X,2)
  tau = tau_0
  delta_S = 2*tol_convergence
  Lip = Lip_0
  #g_old = 0.5*norm(y-theta_opt)^2 + 0.5*lambda_reg*sum([norm(Xi_opt[:,i])^2 for i in 1:d]);
  S_new = zeros(Int64,k)
  theta_new = zeros(n)

  while(tau > tau_tol)
    #f_old = 0.5*norm(y-theta_opt)^2
	delta = 2*tol_convergence
	
    while(delta > tol_convergence)
      # X,y,k,theta_opt, Xi_opt,idxs,Psi_1,Lip,eta,grad_theta,tau
	  #@show delta
      S_new,theta_new,Xi_new,Lip,f_new,f_old = iterative_thresholding_backtracking(X,y,k,theta_opt, Xi_opt,idxs,is_leq,Psi_1,Psi_2,Lip,eta,tau, lambda_reg)
	  #@show f_old 
	  #@show f_new
      delta = f_old - f_new
	  #@show delta
      S_opt = copy(S_new)
      theta_opt = copy(theta_new)
      Xi_opt = copy(Xi_new)
	  f_old = copy(f_new)
	  #@show tol_convergence
	  
    end # Inner convergence
    tau = copy(gamma*tau)
	Lip = copy(Lip_0)
  end # Outer loop varying tau
  
  # return final support

  return S_new, theta_new
end

######################################################################3

function iterative_thresholding_backtracking(X,y,k,theta_opt, Xi_opt,idxs,is_leq,Psi_1,Psi_2,Lip,eta,tau, lambda_reg)
  n = size(X,1)
  d = size(X,2)
  success = 0
  L_bar = copy(Lip)
  lambda_dim = size(idxs,1)
  lambda = zeros(lambda_dim)
  lambda_new = zeros(lambda_dim)
  Xi_new = zeros(n,d)
  theta_new = zeros(n)
  S_new = zeros(Int64,k)
  n = length(y)
  d = size(X,2)

  for i in 1:lambda_dim
      i1 = idxs[i,1]
      i2 = idxs[i,2]
	  if(i1 >0 && i2 > 0)
		  #@show size(X)
		  #@show size(Xi_opt)
		  if(is_leq[i]  == 1)
		  
			lambda[i] = maximum([(theta_opt[i1] + dot(vec(X[i2,:] - X[i1,:]),vec(Xi_opt[i1,:])) - theta_opt[i2]) ,0])
		  else
			lambda[i] = (theta_opt[i1] + dot(vec(X[i2,:] - X[i1,:]),vec(Xi_opt[i1,:])) - theta_opt[i2])
		  end
	  end
  end
  lambda = lambda/tau

  f_val_old = 0.5*norm(y-theta_opt)^2 + 0.5*lambda_reg*sum([norm(Xi_opt[:,i])^2 for i in 1:d]) + (0.5)*tau*norm(lambda,2)^2
  f_val = 0
  grad_theta = zeros(n)
  for i in 1:n
	#@show Psi_1[i]
	#@show Psi_2[i]
    grad_theta[i] =  sum([lambda[j] for j in Psi_1[i]]) - sum([lambda[j] for j in Psi_2[i]])
  end
  while(success == 0)

    # Compute theta(L_bar), Xi(L_bar).
    u = zeros(d)
	
    for i in 1:n
	    grad_Xi = zeros(1,d)
		if(length(Psi_1[i])>0)
			grad_Xi = sum([(X[idxs[ind,2],:] - X[i,:])*lambda[ind] for ind in Psi_1[i]])
		end
        Xi_new[i,:] = (L_bar/(L_bar + lambda_reg))*( Xi_opt[i,:] - (1/L_bar)*(grad_Xi));

        for j in 1:d
           u[j] += Xi_new[i,j]^2
        end

    end
	#@show u
    # Sort u.
    S_new = sortperm(u,rev=true)
    S_new = S_new[1:k]

    # Form Xi_new, theta_new.
    theta_new = (1/(1+L_bar))*(y + L_bar*theta_opt - grad_theta)
	
    g_val = 0
	
    for i in 1:n
      for j in 1:d
        if(in(j,S_new) == 0)
          Xi_new[i,j] = 0
        end
      end
	  grad_Xi = zeros(d)'
	  if(length(Psi_1[i]) > 0)
		grad_Xi = sum([(X[idxs[ind,2],:] - X[i,:])*lambda[ind] for ind in Psi_1[i]])
	  end
      g_val += 0.5*L_bar*(norm(Xi_new[i,:] - Xi_opt[i,:])^2) + dot(vec(grad_Xi),vec(Xi_new[i,:] - Xi_opt[i,:]));
    end
    # Evaluate f.

    for i in 1:lambda_dim
      i1 = idxs[i,1]
      i2 = idxs[i,2]
	  if(i1 >0 && i2 > 0)
		  if(is_leq[i]  == 1)
			lambda_new[i] = maximum([(theta_new[i1] + dot(vec(X[i2,:] - X[i1,:]),vec(Xi_new[i1,:])) - theta_new[i2]) ,0])
		  else
			lambda_new[i] = (theta_new[i1] + dot(vec(X[i2,:] - X[i1,:]),vec(Xi_new[i1,:])) - theta_new[i2])
		  end
	  end

    end
	lambda_new = lambda_new/tau
    f_val = 0.5*norm(y-theta_new)^2 + (0.5*lambda_reg*sum([norm(Xi_new[:,i])^2 for i in 1:d]))+ (0.5*tau)*norm(lambda_new,2)^2
    # Evaluate g.
    g_val += f_val_old + 0.5*(L_bar)*norm(theta_new - theta_opt)^2 + dot(vec(grad_theta),vec(theta_new - theta_opt))

    if(f_val <= g_val || L_bar > 1e5)
      success = 1
    else
      L_bar = eta*(L_bar)
	  
    end

  end # success loop.
  
  return S_new, theta_new, Xi_new, L_bar, f_val, f_val_old
end

#################################################

function binding_constraints_list(X,theta_sol,Xi_sol,tol)

  pairs = Array(Vector{Int64},0); # Array of vectors.
  for i in 1:n
    for j in 1:n
      if( j != i)
        check = theta_sol[i] - theta_sol[j] + dot(vec(Xi_sol[i,:]),vec(X[j,:] - X[i,:]))
        if(abs(check) < 1e-4)
          push!(pairs,[i,j])
        end
      end # j != i.
    end # for j loop.
  end # for i loop.
  pairs_matrix = zeros(Int,length(pairs),2)
  for i in 1:length(pairs)
	pairs_matrix[i,1] = pairs[i][1]
	pairs_matrix[i,2] = pairs[i][2]
  end
  return pairs, pairs_matrix
end

function Psi_list(idxs_matrix)
	constraint_index_1 = Array(Vector{Int64},0); # Array of vectors.
	constraint_index_2 = Array(Vector{Int64},0); # Array of vectors.
	for i in 1:n
		indices_i = find(idxs_matrix[:,1].== i)
		push!(constraint_index_1, indices_i)
		indices_i = find(idxs_matrix[:,2].== i)
		push!(constraint_index_2, indices_i)
	end
	return constraint_index_1,constraint_index_2
end

################
function L2_sparse_cutting_plane_MIO(X,y,k,max_cuts,tol,idxs,bigM,time_limit,mip_gap, z_0, theta_0, Xi_0)

  n = length(y)
  p = size(X,2)
  z_opt_path = Array(Vector{Int64},0);
  
  # Define the reduced master problem.
  getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
  m_outer = Model(solver=GurobiSolver(TimeLimit = time_limit, MIPGap= mip_gap, Threads=getthreads()))#(OutputFlag = 0))# Crossover=0
  @variable(m_outer,z[1:p],Bin)
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  
  @constraint(m_outer,UB_constr[i=1:p,j=1:n], Xi[j,i] <= bigM*z[i]);
  @constraint(m_outer,LB_constr[i=1:p,j=1:n], Xi[j,i] >= -bigM*z[i]);
  

  @constraint(m_outer, Cardinality_constr, sum{z[i], i in 1:p} <= k)
  # Solve the reduced problem.
  
  r = size(idxs,2)-1
  numcon = size(idxs,1)
  for i in 1:numcon
	ind1 = idxs[i,1]
	if(ind1 > 0) 
		for j in 1:r
		  ind2 = idxs[i,j+1]
		  if(ind2 > 0)
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,j] - X[ind1,j])*Xi[ind1,j], j =1:p} <= theta[ind2]);
		  end

		end
	end
  end
  
  @objective(m_outer, Min, sum{(y[i] - theta[i])*(y[i] - theta[i]), i=1:n})
  setvalue(z,z_0)
  setvalue(theta, theta_0)
  setvalue(Xi, Xi_0)
  status = solve(m_outer,suppress_warnings=true);
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);
  z_opt = getvalue(z)
  push!(z_opt_path, sort(find(z_opt .> 0.5)))
  @show find(z_opt .== 1)
  @show getobjectivevalue(m_outer)

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  new_idxs = zeros(Int64,n,2)

  # Adding cuts sequentially.
  while(cuts_added <= max_cuts-1 && opt_reached == 0)
    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.
	for i in 1:n

		if (i%10000 == 0)
		  @show i
		end
		# To do: Do the multiplications manually.
		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]' ;
		separation_positive = max(separation,0);

		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = indmax(separation);
		else
			max_index[i] = 0;
		end

    end

    if(sum(max_index) == 0)
      opt_reached = 1;
	  print("Cutting plane converges \n")
	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
	  numcon = length(find(max_index .> 0))
	  new_idxs = zeros(Int64,numcon,2)
	  numcon_count = 1
      for i in 1:n
        j_star = max_index[i];
        if(j_star > 0 )
          @constraint(m_outer, theta[i] + sum{(X[j_star,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[j_star] )
		  new_idxs[numcon_count,1] = i 
		  new_idxs[numcon_count,2] = j_star
		  numcon_count += 1
		  #push!(new_idxs,[i,j_star])
        end
      end
  
	  # Given current support, polish the feasible warm starts.
	  # Solve using Mosek with the current constraints.
	  # Use L2_cutting_plane_NEW
	  S_current = sort(find(z_opt .>= 0.5))
	  @show S_current
	  # Construct new_idxs
	  # Solve with max_cuts = 0 -> only the current problem with the added constraints so far.
	  idxs = vcat(idxs,new_idxs)
	  theta_opt, Xi_opt_1,~, ~, ~,~,~,~ =  L2_cutting_plane_NEW(X[:,S_current],y,0,0.01,10,idxs,bigM,0,1,1)
	  Xi_opt = zeros(n,d)
	  for i in 1:length(S_current)
		Xi_opt[:,S_current[i]] = Xi_opt_1[:,i]
	  end
	  
	  
	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  setvalue(z,z_opt);
	  
	  # Re-solve the problem.
	  @objective(m_outer, Min, sum{(y[i]-theta[i])*(y[i]-theta[i]), i=1:n} )
	  status = solve(m_outer,suppress_warnings=true);
	  push!(z_opt_path, sort(find(z_opt .> 0.5)))
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);
	  z_opt = getvalue(z)
	  @show find(z_opt.== 1)
	end
	# Loop counter.
	cuts_added = cuts_added+1;
  end # end while loop.
  
  @show cuts_added
  return theta_opt, Xi_opt, z_opt, getobjectivevalue(m_outer), cuts_added, z_opt_path
end

######################
function L2_sparse_lazy(X,y,k,max_cuts,tol,idxs,bigM_array,option,time_limit)

  n = length(y)
  p = size(X,2)

  # Define the reduced master problem.
  
  m_outer = Model(solver=GurobiSolver(Crossover=0, TimeLimit = time_limit))#(OutputFlag = 0))
  @variable(m_outer,z[1:p],Bin)
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  @variable(m_outer,t)

  for i in 1:p
	for j in 1:n
		@constraint(m_outer, Xi[j,i] <= bigM_array[i]*z[i]);
		@constraint(m_outer, Xi[j,i] >= -bigM_array[i]*z[i]);
	end
  end

  @constraint(m_outer, sum{z[i], i in 1:p} <= k)
  # Solve the reduced problem.
  r = size(idxs[1],1)-1
  for i in 1:n
	ind1 = i
	r = size(idxs[i],1)-1
	if(option == 1)
		for j in 1:r
			ind2 = idxs[i][j+1]
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,count] - X[ind1,count])*Xi[ind1,count], count =1:p} <= theta[ind2]);
		end
	else
	    for j in 1:r
			ind2 = idxs[i][j+1]
			#@constraint(m_outer, theta[ind1] + sum{(X[ind2,count] - X[ind1,count])*Xi[ind1,count], count =1:p} <= theta[ind2]);
			#@constraint(m_outer, theta[ind2] + sum{(X[ind1,count] - X[ind2,count])*Xi[ind2,count], count =1:p} <= theta[ind1]);
		end

	end
  end


  #@constraint(m_outer, norm2{ (y[i] - theta[i]),i=1:n } <= t);
  #@objective(m_outer, Min, t)
  @objective(m_outer, Min, sum{(y[i] - theta[i])*(y[i] - theta[i]), i=1:n})

  #### Lazy callback

  function convexityCallback(cb)
		print("Callback \n")
		norm_infeasibility = 0
		max_index = zeros(Int64,n)
		for i in 1:n

			if (i%10000 == 0)
			  @show i
			end
			# To do: Do the multiplications manually.
			XiX_i = dot(vec(getvalue(Xi[i,:])),vec(X[i,:]));
			separation = (getvalue(theta[i])-XiX_i)*ones(n,1) - getvalue(theta) + X*getvalue(Xi[i,:]') ;
			separation_positive = max(separation,0);
			norm_infeasibility = norm_infeasibility + norm(separation_positive)^2;
			max_value = maximum(separation)
			if(max_value > tol)
				max_index[i] = indmax(separation);
			else
				max_index[i] = 0;
			end

        end
		norm_infeasibility = sqrt(norm_infeasibility)/n
		@show norm_infeasibility

		isViolated = 0
		if(sum(max_index) > 0)
		  isViolated = 1;
		end

		if(isViolated == 1)
		  # Add constraints, and re-solve.
		  # 1. Add one for each i.
		  # 2. Add the j^*(i) for each i.
		  # 3. j^*(i) = max_index[i].
		  for i in 1:n
			j_star = max_index[i];
			if(j_star > 0 )
			  @lazyconstraint(cb,theta[i] + sum{(X[j_star,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[j_star] )
			end
		  end

		end # if isViolated == 1

	end

	addLazyCallback(m_outer, convexityCallback)



  ### Lazy callback code ends.

  status = solve(m_outer,suppress_warnings=true);
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);
  z_opt = getvalue(z)
  @show find(z_opt .== 1)
  @show getobjectivevalue(m_outer)

  return theta_opt, Xi_opt, z_opt,getobjectivevalue(m_outer)
end




function bigM_Linf_gurobi(X, y, ub, tol, lambda)

  n=length(y)
  p = size(X,2)
  # Define the reduced master problem.
  getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
  m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  @variable(m_outer,t)
  for i in 1:n
	for j in 1:p
		@constraint(m_outer, Xi[i,j] <= t);
		@constraint(m_outer, Xi[i,j] >= -t);
	end 
		
  end

  # Solve the reduced problem.

  for i in 1:n
	ind2 = sample(setdiff(collect(1:n),i), 1, replace=false)[1];
	
	@constraint(m_outer, theta[i] + sum{(X[ind2,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[ind2]);
	
  end

  if(lambda > 0)
	@constraint(m_outer, sum{ (y[i] - theta[i])^2,i=1:n } + lambda*sum{Xi[i,j]^2, i=1:n, j=1:p} <= ub)
	
  else 
	@constraint(m_outer, sum{ (y[i] - theta[i])^2,i=1:n } <= ub)
  end
  @objective(m_outer, Min, t)
  status = solve(m_outer,suppress_warnings=true);
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);
  t_opt = getvalue(t)

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  # Adding cuts sequentially.
 while(cuts_added <= max_cuts-1 && opt_reached == 0)

    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.

	#println("Adding the blocks")
	
	for i in 1:n

		if (i%10000 == 0)
		  @show i
		end
		# To do: Do the multiplications manually.
		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]' ;
		separation_positive = max(separation,0);
		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = indmax(separation);
		else
			max_index[i] = 0;
		end

    end
	
    if(sum(max_index) == 0)
      opt_reached = 1;

	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
      for i in 1:n
        j_star = max_index[i];
        if(j_star > 0 )
          @constraint(m_outer, theta[i] + sum{(X[j_star,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[j_star] )
        end
      end

	  # Set warm starts - Interior point method doesn't accept warm starts.
	  #setValue(theta,theta_opt);
	  #setValue(Xi,Xi_opt);
	  #setValue(t,t_opt)

	  @objective(m_outer, Min, t)
	  status = solve(m_outer,suppress_warnings=true);
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);
	  t_opt = getvalue(t)
	  #@show norm(y-theta_opt)

	end # if-else reached opt
	
	# Loop counter.
    cuts_added = cuts_added+1;
  end # cuts_added while loop.
  
  println("Cutting planes ends ")
  @show cuts_added
  return t_opt, cuts_added

end