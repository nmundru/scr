using JuMP
using Distributions, Gurobi
using MathProgBase, Mosek, Distances, Stats

##################
function L2_full(X,y,n,p)

  m_full = Model(solver=GurobiSolver(OutputFlag = 0))
  @variable(m_full, theta[1:n])
  @variable(m_full, Xi[1:n,1:p])
  for i in 1:n
    for j in 1:n
      if( j != i)
        @constraint(m_full, theta[i] + sum{(X[j,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[j]);
      end
    end
  end

  @objective(m_full, Min, sum{(y[i] - theta[i])^2,i=1:n} )
  status = solve(m_full,suppress_warnings=true);
  return getvalue(theta), getvalue(Xi), getobjectivevalue(m_full)
end



##########################

function L2_cutting_plane_LARGE(X,y,max_cuts,tol,history,bigM,extra_cuts,bounds,sides)

  n = length(y)
  p = size(X,2)
  # Define the reduced master problem.
  m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))#(OutputFlag = 0))
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  
  # Solve the reduced problem.
  inf_array=[];

  if(extra_cuts == 1)

	  @constraint(m_outer, X'*(y - theta) .== 0)

  end
  if(bounds == 1)
	for i in 1:p 
		@constraint(m_outer, Xi[:,i] .<= bigM)
		@constraint(m_outer, Xi[:,i] .>= -bigM)
	end
  end
  
  numcon = n;
  temp_array = [];
  r=1;
  full_violation_pair=[];
  for i in 1:numcon
	  ind1 = i;
	 
    for j in 1:r
	  # Sample randomly from [1:n] after excluding i.
  
      ind2 = sample(setdiff(collect(1:n),i),1,replace=false)[1]; #???

	  if(ind2 > 0)
		if(sides == 1)
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
			push!(full_violation_pair, [copy(ind1), copy(ind2)]);
		else
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
			@constraint(m_outer, theta[ind2] + sum{(X[ind1,ind] - X[ind2,ind])*Xi[ind2,ind], ind =1:p} <= theta[ind1]);
		end
	  end

    end
  end
   println("Finished the constraints")
  @objective(m_outer, Min, sum{(y[i]-theta[i])^2,i=1:n} )
  t1 = time()
  status = solve(m_outer,suppress_warnings=true);
  @show status
  t2 = time()
  obj_value = getobjectivevalue(m_outer);
  actual_time = t2-t1
  println("Solved the reduced master problem")
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  norm_infeasibility = 0;

  initial_numconstr = copy(length(m_outer.linconstr))
  cuts_array = Array(Int64,0)
  Pinf_array = Array(Float64,0)
  MaxV_array = Array(Float64,0)
  MaxV = 0
  # Adding cuts sequentially.
  
 while(cuts_added <= max_cuts-1 && opt_reached == 0)

    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.

	MaxV = 0
	norm_infeasibility = 0;
	
	violation_pair = [];
	
	for i in 1:n
		
		separation = theta_opt[i] - dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		
		separation += BLAS.gemv('N', X, Xi_opt[i,:]) - theta_opt
		
		separation_positive = max(separation,0);
		norm_infeasibility = norm_infeasibility + norm(separation_positive)^2;
		max_value = maximum(separation_positive)
		if(max_value > tol)
			#@show max_value, tol
			max_index[i] = copy(indmax(separation));
			push!(violation_pair, [copy(i), copy(max_index[i])])
		else
			max_index[i] = 0;
		end
		if(max_value > MaxV)
			MaxV = copy(max_value)
		end
		
    end
	
	norm_infeasibility = sqrt(norm_infeasibility)/n;

	push!(Pinf_array,norm_infeasibility )
	push!(MaxV_array, MaxV)

    if(sum(max_index) == 0)
      opt_reached = 1;

	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
      for i in 1:length(violation_pair)
		i_star = copy(violation_pair[i][1]);
        j_star = copy(violation_pair[i][2]);
		
        if(j_star > 0 )
			#@show i_star, j_star
			@constraint(m_outer, theta[i_star] + sum{(X[j_star,ind] - X[i_star,ind])*Xi[i_star,ind], ind =1:p} <= theta[j_star] )
        end
      end
      
	  # Update full_violation_pair.
	  full_violation_pair = [full_violation_pair; violation_pair];
	  
	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  @objective(m_outer, Min, sum{(y[i]-theta[i])^2,i=1:n} )
	  t1 = time()
	  status = solve(m_outer,suppress_warnings=true);
	  t2 = time()
	  actual_time += t2 - t1
	  obj_value = getobjectivevalue(m_outer);
	  
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);

	  # Loop counter.
	  cuts_added = cuts_added+1;

	  if(cuts_added == 1)
	    push!(cuts_array,initial_numconstr)
		push!(cuts_array,length(m_outer.linconstr) - initial_numconstr)
	  else
	    sum_so_far = sum([cuts_array[j] for j in 1:cuts_added])
		push!(cuts_array, length(m_outer.linconstr) - sum_so_far)
	  end
	  @show cuts_array[end]
	  @show length(violation_pair)
	end # if - else - violation found.
  end # cuts_added loop.
  println("Cutting planes ends ")
  @show cuts_added
  @show length(full_violation_pair)
  norm_obj = norm(y-theta_opt)
  return theta_opt, Xi_opt, norm_obj, opt_reached, cuts_array,Pinf_array,MaxV_array, actual_time, obj_value
end


##########################

function L2_cutting_plane_NEW(X,y,max_cuts,tol,history,idxs,bigM,extra_cuts,bounds,sides)

  n = length(y)
  p = size(X,2)
  # Define the reduced master problem.
  m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))#(OutputFlag = 0))
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  @variable(m_outer,t)
  
  # Solve the reduced problem.
  inf_array=[];

  if(extra_cuts == 1)

	  @constraint(m_outer, X'*(y - theta) .== 0)

  end
  if(bounds == 1)
	for i in 1:p ## NEED TO CHANGE THIS.
		@constraint(m_outer, Xi[:,i] .<= bigM)
		@constraint(m_outer, Xi[:,i] .>= -bigM)
	end
  end
  r = size(idxs,2)-1
  numcon = size(idxs,1)
  for i in 1:numcon
	  ind1 = idxs[i,1]
	 
    for j in 1:r
      ind2 = idxs[i,j+1]
	  if(ind2 > 0)
		if(sides == 1)
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
		else
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
			@constraint(m_outer, theta[ind2] + sum{(X[ind1,ind] - X[ind2,ind])*Xi[ind2,ind], ind =1:p} <= theta[ind1]);
		end
	  end

    end
  end

  @objective(m_outer, Min, sum{(y[i]-theta[i])*(y[i]-theta[i]),i=1:n} )
  t1 = time()
  status = solve(m_outer,suppress_warnings=true);
  t2 = time()
  actual_time = t2-t1
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  norm_infeasibility = 0;

  initial_numconstr = copy(length(m_outer.linconstr))
  cuts_array = Array(Int64,0)
  Pinf_array = Array(Float64,0)
  MaxV_array = Array(Float64,0)
  MaxV = 0
  # Adding cuts sequentially.
 while(cuts_added <= max_cuts-1 && opt_reached == 0)

    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.

	MaxV = 0
	norm_infeasibility = 0;
	violation_pair = [];
	
	for i in 1:n

		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]' ;
		separation_positive = max(separation,0);
		norm_infeasibility = norm_infeasibility + norm(separation_positive)^2;
		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = copy(indmax(separation));
			push!(violation_pair, [copy(i), copy(max_index[i])])
		else
			max_index[i] = 0;
		end
		if(max_value > MaxV)
			MaxV = copy(max_value)
		end
    end
	#Profile.print(format=:flat)
	#readline()
	norm_infeasibility = sqrt(norm_infeasibility)/n;

	push!(Pinf_array,norm_infeasibility )
	push!(MaxV_array, MaxV)

    if(sum(max_index) == 0)
      opt_reached = 1;

	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
      for i in 1:length(violation_pair)
		i_star = violation_pair[i][1];
        j_star = violation_pair[i][2];
        if(j_star > 0 )
          @constraint(m_outer, theta[i_star] + sum{(X[j_star,ind] - X[i_star,ind])*Xi[i_star,ind], ind =1:p} <= theta[j_star] )
        end
      end
      
	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  @objective(m_outer, Min, sum{(y[i]-theta[i])*(y[i]-theta[i]),i=1:n} )
	  t1 = time()
	  status = solve(m_outer,suppress_warnings=true);
	  t2 = time()
	  actual_time += t2 - t1
	  
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);

	  # Loop counter.
	  cuts_added = cuts_added+1;

	  if(cuts_added == 1)
	    push!(cuts_array,initial_numconstr)
		push!(cuts_array,length(m_outer.linconstr) - initial_numconstr)
	  else
	    sum_so_far = sum([cuts_array[j] for j in 1:cuts_added])
		push!(cuts_array, length(m_outer.linconstr) - sum_so_far)
	  end
	  #@show cuts_added
	end # if - else - violation found.
  end # cuts_added loop.
  println("Cutting planes ends ")
  @show cuts_added
  norm_obj = norm(y-theta_opt)
  return theta_opt, Xi_opt, norm_obj, opt_reached, cuts_array,Pinf_array,MaxV_array, actual_time
end

####################################
function L1_cutting_plane_NEW(X,y,max_cuts,tol,history,idxs,bigM_array,bounds)

  n = length(y)
  p = size(X,2)
  # Define the reduced master problem.
  m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  @variable(m_outer, slack[1:n] >= 0)

  for i in 1:n
    @constraint(m_outer, slack[i] >= y[i] - theta[i]);
    @constraint(m_outer, slack[i] >= theta[i] - y[i]);
  end

  # Solve the reduced problem.

  if(bounds == 1)
	for i in 1:p
		@constraint(m_outer, Xi[:,i] .<= bigM_array[i])
		@constraint(m_outer, Xi[:,i] .>= -bigM_array[i])
	end
  end
  r = size(idxs,2)-1
  numcon = size(idxs,1)
  for i in 1:numcon
	  ind1 = idxs[i,1]
	 
    for j in 1:r
      ind2 = idxs[i,j+1]
	  if(ind2 > 0)
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,j] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
	  end

    end
  end

  @objective(m_outer, Min, sum{slack[i],i=1:n} )

  t1 = time()
  status = solve(m_outer,suppress_warnings=true);
  t2 = time()
  actual_time = t2 - t1
  
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);
  slack_opt = getvalue(slack);

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  norm_infeasibility = 0;

  initial_numconstr = copy(length(m_outer.linconstr))

  cuts_array = Array(Int64,0)
  Pinf_array = Array(Float64,0)
  MaxV_array = Array(Float64,0)
  MaxV = 0

  # Adding cuts sequentially.
 while(cuts_added <= max_cuts-1 && opt_reached == 0)

    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.

	MaxV = 0
	norm_infeasibility = 0;
	for i in 1:n

		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]' ;
		separation_positive = max(separation,0);
		norm_infeasibility = norm_infeasibility + norm(separation_positive)^2;
		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = indmax(separation);
		else
			max_index[i] = 0;
		end
		if(max_value > MaxV)
			MaxV = copy(max_value)
		end
    end
	
	norm_infeasibility = sqrt(norm_infeasibility)/n;

	push!(Pinf_array,norm_infeasibility )
	push!(MaxV_array, MaxV)

    if(sum(max_index) == 0)
      opt_reached = 1;

	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
      for i in 1:n
        j_star = max_index[i];
        if(j_star > 0 )
          @constraint(m_outer, theta[i] + sum{(X[j_star,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[j_star] )
        end
      end
      

	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  setvalue(slack, slack_opt)

	  @objective(m_outer, Min, sum{slack[i],i=1:n} )
	  t1 = time()
	  status = solve(m_outer,suppress_warnings=true);
	  t2 = time()
	  actual_time += t2 - t1 
	  
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);
	  slack_opt = getvalue(slack)

	  # Loop counter.
	  cuts_added = cuts_added+1;

	  if(cuts_added == 1)
	    push!(cuts_array,initial_numconstr)
		push!(cuts_array,length(m_outer.linconstr) - initial_numconstr)
	  else
	    sum_so_far = sum([cuts_array[j] for j in 1:cuts_added])
		push!(cuts_array, length(m_outer.linconstr) - sum_so_far)
	  end
	end # if - else - violation found.
  end # cuts_added loop.
  @show cuts_added
  return theta_opt, Xi_opt, getobjectivevalue(m_outer), opt_reached, cuts_array,Pinf_array,MaxV_array,actual_time
end


####################################
