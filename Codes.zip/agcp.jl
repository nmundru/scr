using JuMP
using Distributions, Gurobi
using MathProgBase

function agcp(X,y,tol,G0,L, max_cuts,bounds)

  n = length(y)
  d = size(X,2)
  # Define the reduced master problem.
  getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
  m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))#(OutputFlag = 0))

  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:d])
 
 if(bounds == 1)
	  for i in 1:n
		@constraint(m_outer, Xi[i,:] .<= L);
		@constraint(m_outer, Xi[i,:] .>= -L);
	  end
  end

  # Solve the reduced problem.
  
  for i in 1:n
	
	ind1 = i
	G0[i] = G0[i][find(G0[i] .> 0)]
	
	@constraint(m_outer, sum{theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:d}-theta[ind2], ind2 in G0[i]} <= 0);
	
  end
  
  @objective(m_outer, Min, sum{(y[i]-theta[i])*(y[i]-theta[i]),i=1:n} )
  t1 = time()
  status = solve(m_outer,suppress_warnings=true);
  t2 = time()
  solve_time = t2 - t1
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);

  # Check for violations.

  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  norm_infeasibility = 0;

  initial_numconstr = copy(length(m_outer.linconstr))
  cuts_array = Array(Int64,0)
  Pinf_array = Array(Float64,0)
  MaxV_array = Array(Float64,0)
  MaxV = 0
  # Adding cuts sequentially.
  
  Cnb = zeros(Int64,1,2)
  
 while(cuts_added <= max_cuts-1 && opt_reached == 0)
	#@show cuts_added
    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.

	MaxV = 0
	norm_infeasibility = 0;
	
	for i in 1:n

		
		# To do: Do the multiplications manually.
		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]));
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]' ;
		separation_positive = max(separation,0);
		norm_infeasibility = norm_infeasibility + norm(separation_positive)^2;
		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = indmax(separation);
		else
			max_index[i] = 0;
		end
		if(max_value > MaxV)
			MaxV = copy(max_value)
		end
    end
	#@show MaxV
	norm_infeasibility = sqrt(norm_infeasibility)/n;
	#@show norm_infeasibility
	push!(Pinf_array,norm_infeasibility )
	push!(MaxV_array, MaxV)

	
    if(sum(max_index) == 0)
      opt_reached = 1;

	  # Else, add constraint, and re-solve.
    else
		getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
		m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))
		@variable(m_outer, theta[1:n])
		@variable(m_outer, Xi[1:n,1:d])
		 
		if(bounds == 1)
		  for i in 1:n
			@constraint(m_outer, Xi[i,:] .<= L);
			@constraint(m_outer, Xi[i,:] .>= -L);
		  end
		end

      
	  for i in 1:size(Cnb,1)
		i1 = Int(Cnb[i,1])
		i2 = Int(Cnb[i,2])
		if(i1 > 0 && i2 > 0)
			@constraint(m_outer, theta[i1] + sum{(X[i2,ind] - X[i1,ind])*Xi[i1,ind], ind =1:d} <= theta[i2] )
		end
	  end
	  
	  # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
	  
     for i in 1:n
        j_star = max_index[i];
        if(j_star > 0 )
          @constraint(m_outer, theta[i] + sum{(X[j_star,ind] - X[i,ind])*Xi[i,ind], ind =1:d} <= theta[j_star] )
		  # Update G0.
		  if(in(j_star,G0[i]) == 1)
			G0[i][find(G0[i] .== j_star)] = 0
		  end
		  G0[i] = G0[i][find(G0[i] .> 0)]
		  Cnb = vcat(Cnb, [i;j_star]')
        end
      end

	  # G0 - Updated aggregation constraints.
	  
	  for i in 1:n 
		ind1 = i
		@constraint(m_outer, sum{theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:d}-theta[ind2], ind2 in G0[i]} <= 0);
		
	  end
	  
	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  @objective(m_outer, Min, sum{(y[i]-theta[i])*(y[i]-theta[i]),i=1:n} )
	  
	  t1 = time()
	  status = solve(m_outer,suppress_warnings=true);
	  t2 = time()
	  solve_time += t2 - t1 
	  
	  theta_opt = getvalue(theta);
	  Xi_opt = getvalue(Xi);

	  # Loop counter.
	  cuts_added = cuts_added+1;

	  if(cuts_added == 1)
	    push!(cuts_array,initial_numconstr)
		push!(cuts_array,length(m_outer.linconstr) - initial_numconstr)
	  else
	    sum_so_far = sum([cuts_array[j] for j in 1:cuts_added])
		push!(cuts_array, length(m_outer.linconstr) - sum_so_far)
	  end
	  #@show cuts_added
	end # if - else - violation found.
  end # cuts_added loop.
  
  return theta_opt, Xi_opt, getobjectivevalue(m_outer), opt_reached, cuts_array,Pinf_array,MaxV_array, solve_time,norm_infeasibility
end