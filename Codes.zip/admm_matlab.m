function [theta, Xi, iter, PInf, norm_G_error, convergence] = admm_matlab(X,y,rho,tol1,tol2,DeltaDeltaT_inv,D,max_iter)

  n =  size(X,1);
  d = size(X,2);
  % Use for updating \Xi.
  iter=0;
  convergence = 0;
  
  % Start with Xi, theta, eta, and Nu.
  % Initialization.
  theta = zeros(n);
  Xi = zeros(n,d);
  Nu = zeros(n,n);
  eta = zeros(n,n);
  
  % Iteration loop.
  Delta_ij_Xi_j = zeros(n,n);
  PInf = 0;
  norm_G_error = 0;
  
  while(convergence == 0 && iter <= max_iter)

    % a. Updating Xi.
	
    for j = 1:n
        Delta_j_eta_bar = zeros(d,1);
        for i = 1:n 
            Delta_j_eta_bar = Delta_j_eta_bar + (X(i,:)-X(j,:))'*(Nu(i,j)/rho + eta(i,j) - (theta(j) - theta(i)));  
        end
		
		Xi(j,:) = (DeltaDeltaT_inv(:,:,j)*Delta_j_eta_bar)';
    end
    % b. Updating theta.
	for i = 1:n
        for j =1:n
            Delta_ij_Xi_j(i,j) = dot(X(i,:) - X(j,:),Xi(j,:));  
        end
    end
	%reshape(A.',[],1)
	
	v = y + D'*reshape(Nu.',[],1) + rho*D'*reshape((eta - Delta_ij_Xi_j).',[],1);
    sum_v = sum(v);
	theta = (v + 2*rho*sum_v)/(1+2*n*rho);
    
	% c. eta 
	%eta = convert(Array{Float64,2}, [ minimum( [theta[j] +  Delta_ij_Xi_j[i,j] - theta[i] - (1/rho)*Nu[i,j] ; 0]) for i in 1:n,j in 1:n])
	PInf = 0;
    for i=1:n 
        for j=1:n
            eta(i,j) = max(theta(j) +  Delta_ij_Xi_j(i,j) - theta(i) - (1/rho)*Nu(i,j),0);
            
            % d. Nu
	
            Nu(i,j) = Nu(i,j) +  rho*(eta(i,j) - (theta(j)-theta(i)+ Delta_ij_Xi_j(i,j)));
            
            % Compute PInf
            PInf = PInf+ (eta(i,j) - Delta_ij_Xi_j(i,j) - theta(j) + theta(i))^2;
        end
    end
	
    iter = iter+1;
    % Check if algorithm has converged.
    % If yes, convergence = 1.
	
	
	PInf = sqrt(PInf)/n;
    G_error = theta-y-D'*reshape(Nu.',[],1);
	norm_G_error = norm(G_error);
    iter, PInf, norm_G_error
    if(PInf < tol1 && norm_G_error < tol2)
      convergence = 1;
    end
  end

end


