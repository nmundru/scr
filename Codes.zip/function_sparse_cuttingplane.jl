using JuMP
using Distributions, Gurobi
using MathProgBase, Mosek, Distances, Stats

function GetMuIndex(i,j,pairs)
	count = Int(0);
	for ind in 1:i-1 
		# Check if pairs[ind] exists?
		count += length(pairs[ind]);
	end
	
	for ind in 1:length(pairs[i])
		# Count number of elements that are <= j.
		if(pairs[i][ind] <= j)
			count += 1
		end
	end
	
	return count;
end

function getMuIndex(j, j1, constraint_num)
    for idx in 1:length(constraint_num)
      if constraint_num[idx] == (j, j1)
        return idx
      end
    end
    return 0
end

##########################



function SolvePrimalCuttingPlanes_PrimalConstraintGen(X, y, k, z_iter, lambda, pairs, max_iter, infeasibility_tol)
	
	# Use cutting planes for the outer binary, and then solve the inner primal using constraint generation (call Gurobi for the dual variables).
	 n = length(y);
     d = size(X,2);
	 
	 # Define the reduced problem.
	 
	 num_var_mu = Int64(0);
	 for i in 1:n 
		num_var_mu += length(pairs[i]);
	 end
	 @show num_var_mu
	 ## num_var_mu = Number of constraints added.
	 pairs_new = Array(Vector{Int64}, n);
	 
	 S_current = sort(find(z_iter .>= 0.9));
	 X_new = X[:,S_current];
	 ### Iteratively, add variables to improve the objective.
	 iter = 1;
	 converge = Int64(0);
	 
	 theta_opt = zeros(n);
	 Xi_opt = zeros(d,n);
	 max_index = zeros(Int64,n);
	 k1 = Int(length(S_current));
	 
	 getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
	 m_primal = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads(),  NumericFocus=1));
	 @variable(m_primal, theta[1:n]);
	 @variable(m_primal, Xi[1:k1, 1:n]);	 

	 convexity_constr = Array(Any,n)
	 constraint_num = Array(Any,0)
	 
	 for i in 1:n 
		pairs_new[i] = copy(pairs[i]);
		for j in pairs[i] ## length(pairs[i]) = 1.
		
			convexity_constr[i] = @constraint(m_primal, theta[i] + sum{ Xi[ind, i]*(X_new[j, ind] - X_new[i, ind]), ind in 1:k1} <= theta[j]);
			push!(constraint_num, (copy(i),copy(j)))
		end
	 end
	 
	 @objective(m_primal, Min, sum{(y[i] - theta[i])^2, i=1:n} + lambda*sum{Xi[i,j]^2, i=1:k1,j=1:n});
	 status = solve(m_primal, suppress_warnings=true);
	 
	 obj_val = getobjectivevalue(m_primal);
	 
	 Xi_opt = getvalue(Xi);
	 theta_opt = getvalue(theta);
	
	 while(iter <= max_iter && converge == 0)
		
		# Check separation problem.
		for i in 1:n  
			# Find max of \theta_i -\theta_j + \Bxi_i'(x_j - x_i).
			# Check if it is more than tol.
			XiX_i = dot(vec(Xi_opt[:,i]'),vec(X_new[i,:]'));
			separation = (theta_opt[i]-XiX_i)*ones(n) - theta_opt + X_new*Xi_opt[:,i] ;
			max_value = maximum(separation);

			if(max_value > infeasibility_tol)
				max_index[i] = indmax(separation);
			else
				max_index[i] = 0;
			end	
			
		end
		
		# If violation, add constraints, and re-solve.
		if(sum(max_index) > 0)
			for i in 1:n 
				if(max_index[i] > 0)
					# Add the violated constraint.
				    push!(convexity_constr, @constraint(m_primal, theta[i] + sum{(X_new[max_index[i], ind] - X_new[i, ind])*Xi[ind, i], ind in 1:length(S_current)} <= theta[max_index[i]]));
					# Update pairs_new, Reverse_pairs.
					push!(pairs_new[i], copy(max_index[i]))
					push!(constraint_num, (copy(i),copy(max_index[i])))
				end
			end
			
			# Re-solve and update the solution.
			@objective(m_primal, Min, sum{(y[i] - theta[i])^2, i=1:n} + lambda*sum{Xi[i,j]^2, i=1:k1,j=1:n});
			status = solve(m_primal, suppress_warnings=true)
			obj_val = getobjectivevalue(m_primal)
			@show status
			Xi_opt = getvalue(Xi)
			theta_opt = getvalue(theta)
			
		else
			# Else, set converge == 1.

			converge = 1
		end
		
		iter += 1
		
	 end # while(iter <= max_iter) loop.	 
	 
	 @show iter, converge

	# Compute objective, and gradient.
	g_val = 0.5*obj_val
	@show g_val
	
	grad_g = zeros(d)
	mu = -getdual(convexity_constr)
	for j in 1:n
		for dim in 1:d
			grad_g[dim] += sum(mu[getMuIndex(j,j1,constraint_num)] * (X[j, dim] - X[j1, dim]) for j1 in pairs_new[j]) ^ 2
		end
		#grad_g += (sum([ mu[GetMuIndex_new(j,j1,constraint_num)]*(X[j,:] - X[j1,:]) for j1 in pairs_new[j] ])) .* (sum([ mu[GetMuIndex_new(j,j1,constraint_num)]*(X[j,:] - X[j1,:]) for j1 in pairs_new[j] ]))
	end
	grad_g *= -(0.5/lambda)
	
	return g_val, grad_g
end


########################

function L2_cutting_plane_LARGE_L2reg(X,y,max_cuts,tol,bigM,bounds,sides, lambda)

  n = length(y)
  p = size(X,2)
  # Define the reduced master problem.
  getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
  m_outer = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()))#(OutputFlag = 0))
  @variable(m_outer, theta[1:n])
  @variable(m_outer, Xi[1:n,1:p])
  
  # Solve the reduced problem.
  inf_array=[];

  
  if(bounds == 1)
	for i in 1:p 
		@constraint(m_outer, Xi[:,i] .<= bigM)
		@constraint(m_outer, Xi[:,i] .>= -bigM)
	end
  end
  
  numcon = n;
  temp_array = [];
  for i in 1:numcon
	  ind1 = i;
	 
    for j in 1:r
	  # Sample randomly from [1:n] after excluding i.
  
      ind2 = sample(setdiff(collect(1:n),i),1,replace=false)[1];

	  if(ind2 > 0)
		if(sides == 1)
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
		else
			@constraint(m_outer, theta[ind1] + sum{(X[ind2,ind] - X[ind1,ind])*Xi[ind1,ind], ind =1:p} <= theta[ind2]);
			@constraint(m_outer, theta[ind2] + sum{(X[ind1,ind] - X[ind2,ind])*Xi[ind2,ind], ind =1:p} <= theta[ind1]);
		end
	  end

    end
  end
   println("Finished the constraints")
  @objective(m_outer, Min, sum{(y[i]-theta[i])^2,i=1:n} + lambda*sum{Xi[i,j]^2, i=1:n, j=1:p})
  t1 = time()
  status = solve(m_outer,suppress_warnings=true);
  t2 = time()
  actual_time = t2-t1
  println("Solved the reduced master problem")
  theta_opt = getvalue(theta);
  Xi_opt = getvalue(Xi);
  obj_value = getobjectivevalue(m_outer)
  
  cuts_added = 0;
  opt_reached = 0;

  separation = zeros(n);
  separation_positive = zeros(n);
  max_index = zeros(Int,n)

  norm_infeasibility = 0;

  initial_numconstr = copy(length(m_outer.linconstr))
  cuts_array = Array(Int64,0)
  Pinf_array = Array(Float64,0)
  MaxV_array = Array(Float64,0)
  MaxV = 0
  # Adding cuts sequentially.
 while(cuts_added <= max_cuts-1 && opt_reached == 0)

    # Define the separation problem.
    # Sorting.
    # If no violation, then opt_reached == 1.
    # For each i, find a cut.

	MaxV = 0
	norm_infeasibility = 0;
	#println("Adding the blocks")
    #@profile
	for i in 1:n

		# To do: Do the multiplications manually.
		XiX_i = dot(vec(Xi_opt[i,:]),vec(X[i,:]))
		separation = (theta_opt[i]-XiX_i)*ones(n,1) - theta_opt + X*Xi_opt[i,:]
		separation_positive = max(separation,0);
		norm_infeasibility = norm_infeasibility + norm(separation_positive)^2
		max_value = maximum(separation)
		if(max_value > tol)
			max_index[i] = copy(indmax(separation))
		else
			max_index[i] = 0
		end
		if(max_value > MaxV)
			MaxV = copy(max_value)
		end
    end
	#Profile.print(format=:flat)
	#readline()
	norm_infeasibility = sqrt(norm_infeasibility)/n;

	#@show norm_infeasibility
	push!(Pinf_array,norm_infeasibility )
	push!(MaxV_array, MaxV)

    if(sum(max_index) == 0)
      opt_reached = 1;

	  # Else, add constraint, and re-solve.
    else
      # 1. Add one for each i.
      # 2. Add the j^*(i) for each i.
      # 3. j^*(i) = max_index[i].
      for i in 1:n
        j_star = max_index[i];
        if(j_star > 0 )
          @constraint(m_outer, theta[i] + sum{(X[j_star,ind] - X[i,ind])*Xi[i,ind], ind =1:p} <= theta[j_star] )
        end
      end
      
	  # Set warm starts.
	  setvalue(theta,theta_opt);
	  setvalue(Xi,Xi_opt);
	  @objective(m_outer, Min, sum{(y[i]-theta[i])^2,i=1:n} + lambda*sum{Xi[i,j]^2, i=1:n, j=1:p})
	  t1 = time()
	  status = solve(m_outer,suppress_warnings=true);
	  t2 = time()
	  actual_time += t2 - t1
	  
	  theta_opt = getvalue(theta)
	  Xi_opt = getvalue(Xi)
	  obj_value = getobjectivevalue(m_outer)
	  # Loop counter.
	  cuts_added = cuts_added+1;

	  if(cuts_added == 1)
	    push!(cuts_array,initial_numconstr)
		push!(cuts_array,length(m_outer.linconstr) - initial_numconstr)
	  else
	    sum_so_far = sum([cuts_array[j] for j in 1:cuts_added])
		push!(cuts_array, length(m_outer.linconstr) - sum_so_far)
	  end
	  #@show cuts_added
	end # if - else - violation found.
  end # cuts_added loop.
  println("Cutting planes ends ")
  @show cuts_added
  norm_obj = norm(y-theta_opt)
  return theta_opt, Xi_opt, norm_obj, opt_reached, cuts_array,Pinf_array,MaxV_array, actual_time, 0.5*obj_value

end


### Relaxation heuristic. ###

function relaxation_heuristic(X,y, k,tol, pairs, Reverse_pairs, nonempty_reverse, max_cuts, lambda_reg)

	n = size(X,1);
	d = size(X,2);
	
	getthreads() = haskey(ENV, "SLURM_JOB_CPUS_PER_NODE") ? parse(Int, ENV["SLURM_JOB_CPUS_PER_NODE"]) : 0
	m_dual = Model(solver=GurobiSolver(OutputFlag = 0, Threads=getthreads()));
		
	num_var_mu = size(X,1);
	
	@variable(m_dual, mu[1:num_var_mu] >= 0);
	@variable(m_dual, gamma >= 0)
		 
	
	empty_reverse = setdiff(collect(1:n),nonempty_reverse)
	@objective(m_dual, Min, sum{(y[i] - mu[i] + sum{mu[j], j in Reverse_pairs[i]})^2, i in nonempty_reverse} + sum{(y[i] - mu[i])^2, i in empty_reverse} + (1/lambda_reg)*gamma ); 
	t0 = time()
	status = solve(m_dual, suppress_warnings=true);
	@show time() - t0
	gamma_val = getvalue(gamma);
	mu_val = getvalue(mu);
	
	temp_array = zeros(n)
	iter = 1;
	top_k = [];
	success = 0;
	
	while(success == 0 && iter <= max_cuts)
		# Sort the k maximum values of \sum_{i=1}^n v[j,i]^2.
				
		temp_array = sum([ ((X[i,:] - X[pairs[i,2],:])'*mu_val[i]) .* ((X[i,:] - X[pairs[i,2],:])'*mu_val[i]) for i in 1:n])
		sorted_indices = sortperm(temp_array[1,:], rev=true)
		top_k = sorted_indices[1:k]
		@show top_k
		@show sum([ temp_array[j] for j in top_k]) - gamma_val
		
		if(sum([ temp_array[j] for j in top_k]) <= gamma_val + tol)
			success = 1;
		else 
			##v[:,i] == ((X[i,:] - X[pairs[i,2],:])'*mu[i])
			##v[i,j] == (X[j,i] - X[pairs[j,2],i])*mu[j]
			# Add the constraint, and re-solve.
			@constraint(m_dual, sum{ ((X[j,i] - X[pairs[j,2],i])*mu[j] )^2, i in top_k, j = 1:n} <= gamma);
			status = solve(m_dual, suppress_warnings=true);
			gamma_val = getvalue(gamma);
			mu_val = getvalue(mu);
		end
		
		iter += 1;
	end
	
	return top_k;
end
