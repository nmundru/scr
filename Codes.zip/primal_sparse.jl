using JuMP
using Distributions, Gurobi
using MathProgBase
using HDF5, JLD

include("functions.jl")
include("function_sparse_cuttingplane.jl") # For solving with Tikhonov regularization.
include("function_sparse_MIObigM.jl")
include("function_sparse_MIObigM_LARGE.jl")

############################


n0 = parse(Int,ARGS[1])
d = parse(Int,ARGS[2])
k = parse(Int,ARGS[3])
tol = 0.05 # for reported results.
input_file = parse(Int,ARGS[5]) # controls input data -> between 1 and 10.
time_limit = parse(Int, ARGS[6]) # Time limit for Gurobi Solver.
max_cuts_sparse = 0 #parse(Int,ARGS[7])
mip_gap = 0.001 #parse(Float64,ARGS[8])
final_gap = 0.1 #parse(Float64, ARGS[9])
rho =  #Correlation parameter #parse(Float64, ARGS[10]);
max_iter_sparse = 1;##parse(Int, ARGS[11])
max_try = 0;##parse(Int, ARGS[12])


bigM_array = [0.01; 0.05; 0.1; 0.2; 0.5];

## Read in the data.

X=[];
y=[];
S_true=[];

if(isfile("/Sparse-Data/$n0\_$d\_$k/$input_file/DataRho$rho.jld") )
	workspace_JLD_path = "/Sparse-Data/$n0\_$d\_$k/$input_file/DataRho$rho.jld"
		
	ws = load(workspace_JLD_path)
	S_true = ws["S_true"];
	X = ws["X_train"];
	y = ws["y_train"];
		
end

# Choose best bigM by cross validation.

bigM = 0.01
n = n0;

#############################
max_cuts = 1000;

UB_array = zeros(max_iter_sparse)
LB_array = zeros(max_iter_sparse)
runtime_LB = zeros(max_iter_sparse)
iter = 1
S_opt = zeros(Int64,k)
S_lb = zeros(Int64,k);
gap = 2*final_gap;

t1 = time() 
theta_ub = [];
Xi_ub=[];
z_lb = [];
rand_idxs = zeros(Int64,1,2);

while(gap > final_gap && iter <= max_iter_sparse)
	sides=1
	@show iter
	# Solve for lb.
	tol_sparse = 0.1;
	t3 = time()
	theta_lb, Xi_lb, z_lb, LB_array[iter],~, ~  = L2_sparse_cutting_plane_MIO_LARGE(X,y,k, max_cuts_sparse, tol_sparse, bigM, time_limit, mip_gap,z_lb,theta_ub,Xi_ub)
	t4 = time()
	runtime_LB[iter] = t4-t3 
	@show LB_array[iter]
	S_lb = copy(find(z_lb .>= 0.5))
	S_lb = sort(S_lb)

	# Find violated constraints.
	# Add them to the UB problem as the reduced master.
    
	if(max_iter_sparse > 0)
		viol_idxs =  zeros(Int64, n,2)
		for i in 1:n 
			XiX_i = dot(vec(Xi_lb[i,:]),vec(X[i,:]));
			separation = (theta_lb[i]-XiX_i)*ones(n,1) - theta_lb + X*Xi_lb[i,:]' ;
			separation_positive = max(separation,0);
			max_value = maximum(separation)
			if(max_value > tol_sparse)
				max_index = indmax(separation);
				viol_idxs[i,1] = copy(i);
				viol_idxs[i,2] = copy(max_index);
			end
		end
		rand_idxs = vcat(rand_idxs,viol_idxs)
	end
	
	# Polish S_lb solution to get correpsonding UB.
	max_cuts = 1000;

	theta_ub, Xi_ub_reduced,~,~,~,~,~,~,~ = L2_cutting_plane_LARGE(X[:,S_lb],y,max_cuts,tol,max_cuts,bigM,0,1,1)

	Xi_ub = zeros(n,d);
	for i in 1:length(S_lb)
		Xi_ub[:,S_lb[i]] = Xi_ub_reduced[:,i];
	end
	# Pass them as warm-starts for lower bound problem.

	UB_array[iter] =  (norm(y - theta_ub))^2 ;
	gap = (UB_array[iter] - LB_array[iter])/LB_array[iter];
	@show UB_array[iter]
	@show gap

	iter +=1;

end
t2 = time()

@show S_lb
@show sort(S_true)
@show length(intersect(S_lb,S_true))/k
S_opt = sort(S_lb)

runtime = t2-t1
@show runtime
@show gap
# Save results.