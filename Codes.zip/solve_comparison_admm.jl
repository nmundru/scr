using JuMP
using Distributions, Gurobi
using MathProgBase
using HDF5, JLD, Mosek
using Distances
using DataFrames

include("functions.jl")
include("admm.jl")
include("agcp.jl")

############################
n = parse(Int,ARGS[1])
d = parse(Int,ARGS[2])
C = parse(Int, ARGS[3])
tol = parse(Float64, ARGS[4])

# Generate X, y.

y = zeros(n);
X = randn(n,d);
# Pre-processing. #
SNR = 3.0;
mu = zeros(n);
for i in 1:n
  mu[i] = norm(X[i,:],2)^2;
end
Var_mu = var(mu);
sigma_sq = Var_mu/SNR;
for i in 1:n
  noise = sqrt(sigma_sq)*randn(1);
  noise = noise[1];
  y[i] = mu[i] + noise;
end
# Post processing. #
# Zero mean and unit norm.
y_mean = mean(y);###sum(y)/n;
y = y - y_mean;
y = y/norm(y,2);
x_mean = zeros(d)
for i in 1:d
  x_mean[i] = mean(X[:,i]);##sum([X[j,i] for j in 1:n])/n;
end
X = X - ones(n,1)*x_mean';
for i in 1:d
  X[:,i] = X[:,i]/norm(X[:,i],2);
end

############################


max_cuts = 1000;
history = max_cuts;


norm_infeasibility = zeros(3)
opt_reached = zeros(Int64,3)
cuts_added = zeros(Int64,3)
obj_val = zeros(3)
time_opt = zeros(3)
solve_time = zeros(3)


bigM_array = 0.5*ones(d)
# First attempt.
#tic()
~, ~, UB, opt_reached[1], cuts_array,Pinf_array,MaxV_array,~,~ = L2_cutting_plane_LARGE(X,y,max_cuts,tol,history,bigM_array[1],0,0,1)
#toc()

# Timing the functions.
# ONE_SIDED
sides_option = 1
cuts_option = 0
bounds_option = 0

# Cutting planes - Tree.

t1 = time()
~,~,obj_val[1],opt_reached[1],cuts_array,Pinf_array,MaxV_array, solve_time[1],~ = L2_cutting_plane_LARGE(X,y,max_cuts,tol,history,bigM_array[1],cuts_option,bounds_option,sides_option)
t2 = time()
time_opt[1] = (t2 - t1)
@show time_opt[1]

if(length(cuts_array) == 0)
	norm_infeasibility[1] = Pinf_array[1]

else
	norm_infeasibility[1] = Pinf_array[length(cuts_array)]

end
cuts_added[1] = length(cuts_array)-1



#################
# ADMM

X_y_df = DataFrame(hcat(X,y))
writetable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/ADMM_Xy_data.dat", X_y_df,separator = ',', header = false)


run(`matlab -nodisplay -nosplash -nodesktop -nojvm -r "cd /home/nmundru/S1/Codes, admm_script , quit() "`)

run(`rm /home/nmundru/S1/Codes/RESULTS/Comparisons/All3/ADMM_Xy_data.dat`)

theta_opt_ADMM = readtable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_theta.txt",separator = '\t',header = false)
theta_opt_ADMM = convert(Array, theta_opt_ADMM)

Xi_opt_ADMM = readdlm("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_Xi.txt",',')
Xi_opt_ADMM = convert(Array{Float64,2}, Xi_opt_ADMM)

cuts_ADMM = readtable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_cuts.txt",separator = '\t',header = false)
cuts_ADMM = convert(Array, cuts_ADMM)
cuts_added[3] = Int(cuts_ADMM[1])

PInf_ADMM = readtable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_PInf.txt",separator = '\t',header = false)
PInf_ADMM = convert(Array, PInf_ADMM)
norm_infeasibility[3] = PInf_ADMM[1]

time_ADMM = readtable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_time.txt",separator = '\t',header = false)
time_ADMM = convert(Array, time_ADMM)
time_opt[3] = time_ADMM[1]

GradError_ADMM = readtable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_GradError.txt",separator = '\t',header = false)
GradError_ADMM = convert(Array, GradError_ADMM)
Grad_error = GradError_ADMM[1]

opt_ADMM = readtable("/home/nmundru/S1/Codes/RESULTS/Comparisons/All3/matlab_out_opt.txt",separator = '\t',header = false)
opt_ADMM = convert(Array, opt_ADMM)
opt_reached[3] = convert(Int64, opt_ADMM[1])


obj_val[3] = norm(y-theta_opt_ADMM)

@show norm_infeasibility
@show cuts_added
@show Grad_error
@show time_opt


MaxV_ADMM = 0
	
for i in 1:n

	XiX_i = dot(vec(Xi_opt_ADMM[i,:]),vec(X[i,:]));
	separation = (theta_opt_ADMM[i]-XiX_i)*ones(n,1) - theta_opt_ADMM + X*Xi_opt_ADMM[i,:]' ;
	max_value = maximum(separation)
	
	if(max_value > MaxV_ADMM)
		MaxV_ADMM = copy(max_value)
	end
end
@show MaxV_ADMM
#Save output.