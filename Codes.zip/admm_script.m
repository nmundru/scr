
	% Read in X,y data from the csv file
	X_y = csvread('/Comparisons/All3/ADMM_Xy_data.dat');

	n = size(X_y,1);
	d = size(X_y,2)-1;

	X = X_y(:,1:d);
	y = X_y(:,d+1);

	% Other parameters.
	rho = 1/n;
	tol1 = 1e-1;%0.1
	tol2 = 1e-2;%0.05
	max_iter_admm=1000;

	% Matrix D

	D = zeros(n^2,n);
	IdM = eye(n,n);
	for i = 1:n 
		D((i-1)*n+1:i*n,1:n) = IdM- ones(n,1)*IdM(i,:);%[ j2 == i ? 1 : 0 for j1 in 1:n, j2 in 1:n];
	end

	 
	DeltaDeltaT_inv = zeros(d,d,n);
	for j = 1:n 
		DeltaDeltaT = zeros(d,d);
		for i=1:n
			DeltaDeltaT = DeltaDeltaT +  (X(i,:) - X(j,:))'*(X(i,:) - X(j,:));
		end
		
		DeltaDeltaT_inv(:,:,j) = inv(DeltaDeltaT);
	end
	tStart=tic;
	[theta_opt_ADMM, Xi_opt_ADMM,cuts_ADMM,PInf_ADMM,Grad_error_ADMM,opt_ADMM]  = admm_matlab(X,y,rho,tol1,tol2,DeltaDeltaT_inv,D,max_iter_admm);
	time_ADMM=toc(tStart);

	% Save the output - Write to dat file.
	%sprintf('file_%d.txt',i)
	%dlmwrite(sprintf(),)
	dlmwrite('/Comparisons/All3/matlab_out_theta.txt',theta_opt_ADMM);
	dlmwrite('/Comparisons/All3/matlab_out_Xi.txt',Xi_opt_ADMM);
	dlmwrite('/Comparisons/All3/matlab_out_cuts.txt',cuts_ADMM);
	dlmwrite('/Comparisons/All3/matlab_out_PInf.txt',PInf_ADMM);
	dlmwrite('/Comparisons/All3/matlab_out_GradError.txt',Grad_error_ADMM);
	dlmwrite('/Comparisons/All3/matlab_out_opt.txt',opt_ADMM);
	dlmwrite('/Comparisons/All3/matlab_out_time.txt',time_ADMM);

	exit;

