using JuMP
using JuMPeR
using Distributions, Gurobi
using MathProgBase
using HDF5, JLD, Mosek
using Distances, NearestNeighbors
using DataFrames

include("functions.jl")
include("agcp.jl")

############################
logn = parse(Int,ARGS[1])
n = 10^logn
logd = parse(Int,ARGS[2])
d = 10^logd;
C = parse(Int, ARGS[3])
tol = parse(Float64, ARGS[4])
r=1;
# Generate X, y.

y = zeros(n);
X = randn(n,d);
# Pre-processing. #
SNR = 3.0;
mu = zeros(n);
for i in 1:n
  mu[i] = norm(X[i,:],2)^2;
end
Var_mu = var(mu);
sigma_sq = Var_mu/SNR;
for i in 1:n
  noise = sqrt(sigma_sq)*randn(1);
  noise = noise[1];
  y[i] = mu[i] + noise;
end
# Post processing. #
# Zero mean and unit norm.
y_mean = sum(y)/n;
y = y - y_mean;
y = y/norm(y,2);
x_mean = zeros(d)
for i in 1:d
  x_mean[i] = sum([X[j,i] for j in 1:n])/n;
end
X = X - ones(n,1)*x_mean';
for i in 1:d
  X[:,i] = X[:,i]/norm(X[:,i],2);
end

############################


max_cuts = 1000;
history = max_cuts;


norm_infeasibility = zeros(2)
opt_reached = zeros(Int64,2)
cuts_added = zeros(Int64,2)
obj_val = zeros(2)
time_opt = zeros(2)
solve_time = zeros(2)

# Create ST_pairs
 
ST_pairs=[];
rand_pairs=[];

if(n == 0)
	
	ST_pairs = zeros(Int64,n-1,2)
	rand_pairs = zeros(Int64, n, 2)
	ST_pairs[1,1] = 1
	DistanceMatrix = zeros(n)

	for i in 1:n-1
		
		# Find closest point to pairs[i,1]
		if(i > 1)
		  ST_pairs[i,1] = ST_pairs[i-1,2]
		end
		temp = copy(X[i,:]')
		DistanceMatrix = Distances.colwise(Euclidean(), X', temp[:,1])
		DistanceMatrix[i] = 1000

		success=0
		while(success == 0)
		  min_dist,ST_pairs[i,2] = findmin(DistanceMatrix[:])
		  if(in(ST_pairs[i,2],ST_pairs[1:i,1]) == 0)
			success=1
		  else
			DistanceMatrix[ST_pairs[i,2]] = 1000
		  end
		end
	  
	end
elseif (n == 1)
	## rand_pairs
	rand_pairs = zeros(Int64, n, 2) 
	for i in 1:n 
		# Select r points randomly from n-1 available.
	  temp_array = setdiff(collect(1:n),i)
	  rand_pairs[i,1] = i
	  rand_pairs[i,2:r+1] = sample(temp_array,r,replace=false)
	end
	
	ST_pairs = rand_pairs;
end

bigM_array = 0.5*ones(d)

if( n < 0)
	# First attempt.
	#tic()
	~, ~, UB, opt_reached[1], cuts_array,Pinf_array,MaxV_array,~ = L2_cutting_plane_NEW(X,y,max_cuts,tol,history,ST_pairs,bigM_array,0,0,1)
	#toc()

	# Timing the functions.
	# ONE_SIDED
	sides_option = 1
	cuts_option = 0
	bounds_option = 0

	# Cutting planes - Tree.

	t1 = time()
	theta_opt,Xi_opt,obj_val[1],opt_reached[1],cuts_array,Pinf_array,MaxV_array, solve_time[1] = L2_cutting_plane_NEW(X,y,max_cuts,tol,history,ST_pairs,bigM_array,cuts_option,bounds_option,sides_option)
	t2 = time()
	time_opt[1] = (t2 - t1)
	@show time_opt[1]
	@show solve_time[1]

	if(length(cuts_array) == 0)
		norm_infeasibility[1] = Pinf_array[1]

	else
		norm_infeasibility[1] = Pinf_array[length(cuts_array)]

	end
	cuts_added[1] = length(cuts_array)-1
	obj_val[1] = norm(y-theta_opt)
else  
# L2_cuttingplane_LARGE
	# First attempt.
	#tic()
	~, ~, UB, opt_reached[1], cuts_array,Pinf_array,MaxV_array,~ = L2_cutting_plane_LARGE(randn(100,5),randn(100),max_cuts,tol,history,ones(5),0,0,1)
	#toc()

	# Timing the functions.
	# ONE_SIDED
	sides_option = 1
	cuts_option = 0
	bounds_option = 0

	# Cutting planes - Large scale Random.

	t1 = time()
	theta_opt,~,obj_val[1],opt_reached[1],cuts_array,Pinf_array,MaxV_array, solve_time[1] = L2_cutting_plane_LARGE(X,y,max_cuts,tol,history,bigM_array,cuts_option,bounds_option,sides_option)
	t2 = time()
	time_opt[1] = (t2 - t1)
	@show time_opt[1]
	@show solve_time[1]

	if(length(cuts_array) == 0)
		norm_infeasibility[1] = Pinf_array[1]

	else
		norm_infeasibility[1] = Pinf_array[length(cuts_array)]

	end
	cuts_added[1] = length(cuts_array)-1
	obj_val[1] = norm(y-theta_opt)
end

######### AGCP code.
agcp_time0 = time();
G0 = Vector{Int}[Int[] for i in 1:n]
v1_plus = zeros(n)
v1_minus = zeros(n)

for i in 1:n 
	for j in 1:d 
		v1 = copy(X[i,j]*ones(n) - X[:,j])
		for ind in 1:n  
			v1_plus[ind] = v1[ind] > 0 ? v1[ind] : 1e4
		end
		for ind in 1:n  
			v1_minus[ind] = v1[ind] < 0 ? v1[ind] : -1e4
		end
	
		min_ind = copy(indmin(v1_plus[:]))
		max_ind = copy(indmax(v1_minus[:]))
		push!(G0[i],copy(min_ind))
		push!(G0[i],copy(max_ind))
		
	end 
	
end

agcp_time1 = time();

agcp_init_time = agcp_time1 - agcp_time0;

G0_small = Vector{Int}[Int[] for i in 1:10]
v1_plus = zeros(10)
v1_minus = zeros(10)
X_1 = randn(10,2);
for i in 1:10 
	for j in 1:2
		v1 = copy(X_1[i,j]*ones(10) - X_1[:,j])
		for ind in 1:10 
			v1_plus[ind] = v1[ind] > 0 ? v1[ind] : 1e4
		end
		for ind in 1:10
			v1_minus[ind] = v1[ind] < 0 ? v1[ind] : -1e4
		end
	
		min_ind = copy(indmin(v1_plus[:]))
		max_ind = copy(indmax(v1_minus[:]))
		push!(G0_small[i],min_ind)
		push!(G0_small[i],max_ind)
		
	end 
	
end

println("Initialization done")

~,~,obj_val[2],opt_reached[2],cuts_array,Pinf_array_agcp,MaxV_array_agcp,solve_time[2],norm_infeasibility[2]  = agcp(X_1,randn(10),tol,G0_small,maximum(bigM_array),5,bounds_option)

t1 = time()
theta_opt,~,obj_val[2],opt_reached[2],cuts_array,Pinf_array_agcp,MaxV_array_agcp,solve_time[2],norm_infeasibility[2]  = agcp(X,y,tol,G0,maximum(bigM_array),max_cuts,bounds_option)
t2 = time()
time_opt[2] = t2-t1
@show time_opt[2]
@show solve_time[2]
@show cuts_array
norm_infeasibility[2] = Pinf_array_agcp[end];

cuts_added[2] = length(cuts_array)-1
obj_val[2] = norm(y-theta_opt)

@show norm_infeasibility
#@show solve_time
@show time_opt
@show agcp_init_time

# Save results.
if( tol == 0.1)
	save("/Comparisons/A/$logn\_$logd/File$C.jld","time_opt",time_opt,"cuts",cuts_added,"opt",opt_reached,"tol",tol,"solve_time",solve_time,"norm_infeasibility",norm_infeasibility,"MaxV",MaxV_array,"MaxV_agcp",MaxV_array_agcp,"agcp_init_time",agcp_init_time)
elseif (tol == 0.05)
	save("/Comparisons/B/$logn\_$logd/File$C.jld","time_opt",time_opt,"cuts",cuts_added,"opt",opt_reached,"tol",tol,"solve_time",solve_time,"norm_infeasibility",norm_infeasibility,"MaxV",MaxV_array,"MaxV_agcp",MaxV_array_agcp,"agcp_init_time",agcp_init_time)
end